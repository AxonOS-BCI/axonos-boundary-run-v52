# Governance

Boundary Run v52 follows a lightweight open-governance model.

- Public issues and pull requests are preferred.
- No CLA by default.
- Inbound = outbound license model.
- Maintainer decisions prioritize safety, privacy, determinism, and traceability.
- Forkability is a first-class project property.
